from django.urls import path

from . import views

urlpatterns = [path("", views.index, name="index"),
               path("", views.login, name="login")]

#from .views import get_shipment_details

#urlpatterns = [
#    path('get_shipment_details/', get_shipment_details, name='get_shipment_details'),
#    # Add other URL patterns as needed
#]